from scrapy import cmdline
cmdline.execute("scrapy runspider zl.py".split(" "))